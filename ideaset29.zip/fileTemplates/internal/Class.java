#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
 /**  
  * @Title: ${NAME}
  * @Description: ${description}
  * @author liyingjie
  * @date ${DATE}
  */
public class ${NAME} {
}
